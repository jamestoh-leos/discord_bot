# Discord Music Bot
Built with JavaScript and 2pg-music in the Discord music bot series.

`config.json`:
```
{
  "token": "<your_bot_token>"
}
```